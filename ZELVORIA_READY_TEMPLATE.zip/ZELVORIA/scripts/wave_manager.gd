extends Node

@export var starting_enemies := 3
var current_wave := 0

func start_next_wave() -> void:
    current_wave += 1
    var count := starting_enemies + current_wave * 2
    print("Wave ", current_wave, " enemies: ", count)
