extends Node

var wave: int = 0
var resources := {
    "wood": 0,
    "stone": 0,
    "iron": 0,
    "copper": 0,
    "coal": 0,
    "crystal": 0,
    "rare_ore": 0
}

func add_resource(id: String, amount: int) -> void:
    resources[id] = resources.get(id, 0) + amount
