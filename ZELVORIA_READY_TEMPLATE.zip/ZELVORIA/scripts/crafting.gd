extends Node

var recipes := {
    "stone_wall": {"wood": 4, "stone": 8},
    "iron_pickaxe": {"wood": 2, "iron": 6},
    "torch": {"wood": 1, "coal": 1}
}

func can_craft(id: String, inventory: Dictionary) -> bool:
    if not recipes.has(id):
        return false
    for resource_id in recipes[id]:
        if inventory.get(resource_id, 0) < recipes[id][resource_id]:
            return false
    return true
