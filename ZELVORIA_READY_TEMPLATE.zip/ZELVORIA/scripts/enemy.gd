extends CharacterBody3D
class_name ZelvoriaEnemy

@export var max_health: float = 100.0
@export var damage: float = 10.0
@export var speed: float = 3.0
var health: float

func _ready() -> void:
    health = max_health

func take_damage(value: float) -> void:
    health -= value
    if health <= 0.0:
        queue_free()
