extends Node3D

func _ready() -> void:
    print("ZELVORIA template loaded.")
    print("Добавляй свои модели в assets/ и подключай их к соответствующим сценам.")
