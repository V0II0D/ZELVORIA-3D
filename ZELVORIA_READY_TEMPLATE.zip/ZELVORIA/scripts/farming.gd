extends Node3D
class_name ZelvoriaFarm

@export var growth_time := 30.0
var growth := 0.0
var planted := false

func plant() -> void:
    planted = true
    growth = 0.0

func _process(delta: float) -> void:
    if planted:
        growth += delta
