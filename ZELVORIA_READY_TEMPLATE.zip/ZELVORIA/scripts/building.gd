extends Node3D
class_name ZelvoriaBuilding

@export var max_health: float = 100.0
var health: float

func _ready() -> void:
    health = max_health

func take_damage(amount: float) -> void:
    health = max(0.0, health - amount)
    if health <= 0.0:
        queue_free()

func repair(amount: float) -> void:
    health = min(max_health, health + amount)
