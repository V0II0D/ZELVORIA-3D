extends Node3D
class_name ZelvoriaWeapon

@export var damage := 20.0
@export var attack_range := 2.5
@export var cooldown := 0.5
