extends Node3D
class_name ZelvoriaResource

@export_enum("wood","stone","iron","copper","coal","crystal","rare_ore") var resource_id := "wood"
@export var amount: int = 1

func harvest() -> int:
    var result := amount
    amount = 0
    queue_free()
    return result
