extends Node

var items: Dictionary = {}

func add_item(id: String, amount: int = 1) -> void:
    items[id] = items.get(id, 0) + amount

func remove_item(id: String, amount: int = 1) -> bool:
    if items.get(id, 0) < amount:
        return false
    items[id] -= amount
    if items[id] <= 0:
        items.erase(id)
    return true

func has_item(id: String, amount: int = 1) -> bool:
    return items.get(id, 0) >= amount
